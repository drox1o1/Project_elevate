"use client"

import { useState, useEffect, useRef } from "react"
import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion"
import { ChevronDown, Menu, X, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { HormoneChart } from "@/components/hormone-chart"
import { LifeStagesTimeline } from "@/components/life-stages-timeline"
import { ThemeToggle } from "@/components/theme-toggle"

export default function Home() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [activeSection, setActiveSection] = useState("hero")

  const heroRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"],
  })

  const backgroundY = useTransform(scrollYProgress, [0, 1], ["0%", "30%"])

  useEffect(() => {
    const handleScroll = () => {
      const sections = ["hero", "why", "how", "what", "research"]
      const scrollPosition = window.scrollY + 100

      for (const section of sections) {
        const element = document.getElementById(section)
        if (element) {
          const { offsetTop, offsetHeight } = element
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section)
            break
          }
        }
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const navItems = [
    { id: "hero", label: "Home" },
    { id: "why", label: "Why" },
    { id: "how", label: "How" },
    { id: "what", label: "What" },
    { id: "research", label: "Research" },
  ]

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
    setIsMenuOpen(false)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="fixed top-0 left-0 right-0 z-50 bg-background/80 dark:bg-background/90 backdrop-blur-lg border-b border-border"
      >
        <div className="container mx-auto px-4 md:px-6 py-4 flex items-center justify-between">
          <motion.div whileHover={{ scale: 1.05 }} className="text-xl md:text-2xl font-bold text-[#FF5B04]">
            Oriyali Oura
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6 lg:space-x-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`relative px-3 py-2 text-sm font-medium transition-colors ${
                  activeSection === item.id ? "text-[#FF5B04]" : "text-foreground hover:text-[#FF5B04]"
                }`}
              >
                {item.label}
                {activeSection === item.id && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#FF5B04]"
                    transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                  />
                )}
              </button>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-2">
            <ThemeToggle />
            <Button
              onClick={() => scrollToSection("waitlist")}
              className="bg-[#FF5B04] hover:bg-[#FF5B04]/90 text-white text-sm"
            >
              Join Waitlist
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center gap-2">
            <ThemeToggle />
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2 text-foreground">
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-background dark:bg-background border-t border-border"
            >
              <div className="px-4 md:px-6 py-4 space-y-4">
                {navItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => scrollToSection(item.id)}
                    className="block w-full text-left py-2 text-foreground hover:text-[#FF5B04]"
                  >
                    {item.label}
                  </button>
                ))}
                <Button
                  onClick={() => scrollToSection("waitlist")}
                  className="w-full bg-[#FF5B04] hover:bg-[#FF5B04]/90 text-white"
                >
                  Join Waitlist
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.nav>

      {/* Hero Section with New Parallax Background */}
      <section
        id="hero"
        ref={heroRef}
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
      >
        {/* New Hero Background */}
        <motion.div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: "url('/images/hero-landscape.jpeg')",
            y: backgroundY,
          }}
        />

        {/* Light overlay for better text readability */}
        <div className="absolute inset-0 bg-black/20 z-10"></div>

        <div className="container mx-auto px-4 md:px-6 text-center relative z-20">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", bounce: 0.5, duration: 1 }}
            className="text-6xl md:text-8xl mb-6 md:mb-8"
          >
            ✨
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="text-4xl md:text-6xl lg:text-7xl xl:text-8xl font-light mb-4 md:mb-6 text-white leading-tight drop-shadow-lg"
          >
            Unlock Your
            <br />
            Innate Rhythm
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="text-lg md:text-xl lg:text-2xl text-white mb-8 md:mb-12 max-w-3xl mx-auto leading-relaxed drop-shadow-md px-4"
          >
            Decode your unique neuro-hormonal patterns with personalized, proactive insights to harmonize your mood,
            energy, and focus every day.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center px-4"
          >
            <Button
              onClick={() => scrollToSection("how")}
              size="lg"
              className="bg-[#FF5B04] hover:bg-[#FF5B04]/90 text-white text-base md:text-lg px-6 md:px-8 py-4 md:py-6 shadow-lg hover:shadow-xl transition-all duration-300 w-full sm:w-auto"
            >
              Discover Your Rhythm
              <ArrowRight className="ml-2" size={20} />
            </Button>
          </motion.div>
        </div>

        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Number.POSITIVE_INFINITY, duration: 2 }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20"
        >
          <ChevronDown size={32} className="text-white" />
        </motion.div>
      </section>

      {/* Why Section */}
      <section id="why" className="py-16 md:py-24 bg-card">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-12 md:mb-16"
          >
            <h2 className="text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-light mb-4 md:mb-6 text-[#075056] dark:text-[#9ECFD6] px-4">
              Understanding Your
              <span className="text-[#FF5B04]"> Invisible Burden</span>
            </h2>
            <p className="text-lg md:text-xl text-foreground max-w-4xl mx-auto leading-relaxed px-4">
              For too long, women have navigated the subtle yet profound daily challenge of hormonal fluctuations. These
              shifts deeply impact mood, energy, and focus—often without understanding their root cause.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8 md:gap-12 max-w-6xl mx-auto">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
              className="p-6 md:p-8 h-full bg-background border-l-4 border-[#FF5B04] hover:shadow-lg transition-all duration-300"
            >
              <div className="text-3xl md:text-4xl mb-4">🧘‍♀️</div>
              <h3 className="text-xl md:text-2xl font-light mb-4 text-foreground">The Unspoken Impact</h3>
              <p className="text-foreground leading-relaxed text-sm md:text-base">
                Hormonal shifts throughout the menstrual cycle, pregnancy, and menopause profoundly influence mood,
                cognition, and neurological processes. Symptoms are often dismissed as "just mood swings," leading to a
                hidden weight of under-understood experiences.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              viewport={{ once: true }}
              className="p-6 md:p-8 h-full bg-background border-l-4 border-[#075056] hover:shadow-lg transition-all duration-300"
            >
              <div className="text-3xl md:text-4xl mb-4">🌱</div>
              <h3 className="text-xl md:text-2xl font-light mb-4 text-foreground">A Lifespan of Evolving Needs</h3>
              <p className="text-foreground leading-relaxed text-sm md:text-base">
                Women's health isn't static. From puberty through menopause and beyond, unique needs arise. Current
                solutions often focus narrowly, missing the opportunity to provide continuous, adapting support for a
                woman's entire life journey.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* How Section */}
      <section id="how" className="py-16 md:py-24 bg-background">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-12 md:mb-16"
          >
            <h2 className="text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-light mb-4 md:mb-6 text-[#075056] dark:text-[#9ECFD6] px-4">
              Your Dynamic
              <span className="text-[#FF5B04]"> Bio-Rhythm Navigator</span>
            </h2>
            <p className="text-lg md:text-xl text-foreground max-w-4xl mx-auto leading-relaxed px-4">
              Oriyali Oura doesn't just track; it predicts. By continuously analyzing passive biometric data from your
              wearable, it decodes your body's internal state and provides proactive guidance.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8 mb-12 md:mb-16">
            {[
              {
                icon: "🧠",
                title: "Predictive Intelligence",
                desc: "AI-powered insights that anticipate hormonal shifts before they happen",
              },
              {
                icon: "❤️",
                title: "Scientific Foundation",
                desc: "Built on neuroscience and behavioral psychology research",
              },
              {
                icon: "⚡",
                title: "Real-time Analysis",
                desc: "Continuous monitoring of HRV, heart rate, and temperature",
              },
              { icon: "🔒", title: "Privacy First", desc: "HIPAA/GDPR compliant with end-to-end encryption" },
            ].map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
                className="p-4 md:p-6 bg-card border-b-4 border-[#FF5B04] hover:shadow-lg transition-all duration-300"
              >
                <div className="text-3xl md:text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-base md:text-lg font-light mb-2 text-foreground">{feature.title}</h3>
                <p className="text-foreground text-sm leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>

          {/* Chart Section - No Card Styling */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="max-w-6xl mx-auto"
          >
            <div className="text-center mb-6 md:mb-8">
              <h3 className="text-2xl md:text-3xl font-light mb-4 text-[#075056] dark:text-[#9ECFD6]">
                Hormone Cycle Visualization
              </h3>
              <p className="text-foreground text-sm md:text-base">Interactive insights into your unique patterns</p>
            </div>

            <HormoneChart />
          </motion.div>
        </div>
      </section>

      {/* What Section */}
      <section id="what" className="py-16 md:py-24 bg-card">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-12 md:mb-16"
          >
            <h2 className="text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-light mb-4 md:mb-6 text-[#075056] dark:text-[#9ECFD6] px-4">
              Tools for Your
              <span className="text-[#FF5B04]"> Best Self</span>
            </h2>
            <p className="text-lg md:text-xl text-foreground max-w-4xl mx-auto leading-relaxed px-4">
              From simple, actionable rituals to a companion that grows with you through every life stage, here's what
              you can expect from Oriyali Oura.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-12 md:mb-16">
            {[
              {
                emoji: "🌸",
                title: "Daily Self-Care Rituals",
                desc: "Personalized daily practices that build resilience and well-being",
              },
              {
                emoji: "💡",
                title: "Patentable Innovation",
                desc: "Cutting-edge neuro-hormonal pattern recognition technology",
              },
              {
                emoji: "💊",
                title: "Supplement Integration",
                desc: "Science-backed supplements with educational content and easy ordering",
              },
            ].map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
                className="p-6 md:p-8 bg-background hover:shadow-lg transition-all duration-300"
              >
                <div className="text-4xl md:text-5xl mb-4">{feature.emoji}</div>
                <h3 className="text-lg md:text-xl font-light mb-4 text-foreground">{feature.title}</h3>
                <p className="text-foreground leading-relaxed text-sm md:text-base">{feature.desc}</p>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-8 md:mb-12"
          >
            <h3 className="text-2xl md:text-3xl lg:text-4xl font-light mb-4 text-[#075056] dark:text-[#9ECFD6] px-4">
              A Companion for Your Entire Life
            </h3>
            <p className="text-lg md:text-xl text-foreground max-w-3xl mx-auto mb-8 md:mb-12 px-4">
              The first app designed to adapt with you, providing continuous value from your first period through
              menopause and beyond.
            </p>
          </motion.div>

          <LifeStagesTimeline />
        </div>
      </section>

      {/* Research Section */}
      <section id="research" className="py-16 md:py-24 bg-background">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-12 md:mb-16"
          >
            <h2 className="text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-light mb-4 md:mb-6 text-[#075056] dark:text-[#9ECFD6] px-4">
              Backed by
              <span className="text-[#FF5B04]"> Research</span>
            </h2>
            <p className="text-lg md:text-xl text-foreground max-w-4xl mx-auto leading-relaxed px-4">
              Our insights and recommendations are rooted in the latest scientific understanding of neuro-hormonal
              intelligence and women's well-being.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-card p-6 md:p-8 shadow-xl max-w-4xl mx-auto"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
              <div>
                <h3 className="text-lg md:text-xl font-light mb-4 text-[#075056] dark:text-[#9ECFD6]">
                  Key Research Areas
                </h3>
                <ul className="space-y-3 text-foreground">
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-[#FF5B04] rounded-full mt-2 mr-3 flex-shrink-0" />
                    <span className="text-sm md:text-base">Neuro-hormonal pattern recognition</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-[#FF5B04] rounded-full mt-2 mr-3 flex-shrink-0" />
                    <span className="text-sm md:text-base">Wearable sensor data analysis</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-[#FF5B04] rounded-full mt-2 mr-3 flex-shrink-0" />
                    <span className="text-sm md:text-base">Behavioral psychology interventions</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-[#FF5B04] rounded-full mt-2 mr-3 flex-shrink-0" />
                    <span className="text-sm md:text-base">Menstrual cycle cognitive impacts</span>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg md:text-xl font-light mb-4 text-[#075056] dark:text-[#9ECFD6]">
                  Scientific Foundation
                </h3>
                <p className="text-foreground leading-relaxed text-sm md:text-base">
                  Built on peer-reviewed research from leading institutions including studies on brain fog in
                  perimenopause, premenstrual dysphoric disorder pathophysiology, and wearable sensor applications in
                  mood prediction.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Combined Waitlist and Footer Section with New Background */}
      <section
        id="waitlist"
        className="relative py-16 md:py-24 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: "url('/images/footer-landscape.jpeg')",
        }}
      >
        {/* Overlay for better text readability */}
        <div className="absolute inset-0 bg-black/40 z-10"></div>

        <div className="container mx-auto px-4 md:px-6 text-center relative z-20">
          {/* Waitlist Form */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto mb-16"
          >
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-light mb-4 md:mb-6 text-white px-4">
              Be the First to Experience Oriyali Oura
            </h2>
            <p className="text-lg md:text-xl text-white/90 mb-8 md:mb-12 leading-relaxed px-4">
              Join our exclusive waitlist to get early access and updates. The future of proactive women's wellness is
              coming.
            </p>

            <div className="bg-white/10 backdrop-blur-lg p-6 md:p-8 max-w-md mx-auto rounded-2xl">
              <div className="space-y-4">
                <Input
                  placeholder="Your Name"
                  className="bg-white/20 border-white/30 text-white placeholder:text-white/70 focus:bg-white/30 rounded-full"
                />
                <Input
                  type="number"
                  placeholder="Your Age"
                  className="bg-white/20 border-white/30 text-white placeholder:text-white/70 focus:bg-white/30 rounded-full"
                />
                <Input
                  type="tel"
                  placeholder="Mobile Number"
                  className="bg-white/20 border-white/30 text-white placeholder:text-white/70 focus:bg-white/30 rounded-full"
                />
                <Input
                  type="email"
                  placeholder="Your Email"
                  className="bg-white/20 border-white/30 text-white placeholder:text-white/70 focus:bg-white/30 rounded-full"
                />
                <Button className="w-full bg-[#FF5B04] hover:bg-[#FF5B04]/90 text-white font-bold py-3">
                  Know My Biorhythm
                </Button>
              </div>
            </div>
          </motion.div>

          {/* Footer */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="border-t border-white/20 pt-8"
          >
            <div className="text-xl md:text-2xl font-light mb-4 text-[#FF5B04]">Oriyali Oura</div>
            <p className="text-white/80 text-sm md:text-base">
              © 2025 Oriyali by Terramedici Lifesciences LLP. All Rights Reserved.
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  )
}
