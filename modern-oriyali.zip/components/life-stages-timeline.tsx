"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { useTheme } from "next-themes"

const lifeStages = [
  {
    stage: "Puberty",
    icon: "🌱",
    color: "#F4D47C",
    content:
      "Understanding foundational changes in your body and mind. Oriyali helps establish healthy habits early on, providing guidance through the initial hormonal shifts and emotional changes.",
    features: ["Cycle tracking education", "Emotional wellness support", "Healthy habit formation"],
  },
  {
    stage: "Menstruation",
    icon: "🌸",
    color: "#FF5B04",
    content:
      "Navigate your monthly cycle with predictive insights, turning potential challenges into opportunities for optimized living. Learn to work with your natural rhythms.",
    features: ["Cycle prediction", "Mood tracking", "Energy optimization", "Symptom management"],
  },
  {
    stage: "Pregnancy",
    icon: "🤱",
    color: "#075056",
    darkColor: "#9ECFD6",
    content:
      "Receive support for the unique physical and mental shifts during pregnancy and postpartum, with a focus on maternal mental health and hormonal changes.",
    features: ["Pregnancy tracking", "Postpartum support", "Mental health monitoring", "Sleep optimization"],
  },
  {
    stage: "Perimenopause",
    icon: "🦋",
    color: "#D3DBDD",
    darkColor: "#A0A0A0",
    content:
      "Demystify 'brain fog' and other changes. Get strategies to manage symptoms and maintain cognitive and emotional balance during this transitional phase.",
    features: ["Symptom tracking", "Cognitive support", "Sleep management", "Stress reduction"],
  },
  {
    stage: "Menopause",
    icon: "🌟",
    color: "#233038",
    darkColor: "#A0A0A0",
    content:
      "Embrace this new phase with confidence. Oriyali provides guidance for long-term health, vitality, and well-being in your post-reproductive years.",
    features: ["Health monitoring", "Vitality support", "Bone health", "Heart health tracking"],
  },
]

export function LifeStagesTimeline() {
  const [activeStage, setActiveStage] = useState<number | null>(null)
  const { theme } = useTheme()

  const toggleStage = (index: number) => {
    setActiveStage(activeStage === index ? null : index)
  }

  const getColor = (stage: any) => {
    if (theme === "dark" && stage.darkColor) {
      return stage.darkColor
    }
    return stage.color
  }

  return (
    <div className="w-full max-w-6xl mx-auto">
      {/* Desktop Timeline */}
      <div className="hidden lg:block relative mb-8 md:mb-12">
        <div className="absolute top-1/2 left-0 w-full h-1 bg-border rounded-full -translate-y-1/2"></div>
        <div className="flex justify-between items-start relative">
          {lifeStages.map((stage, index) => (
            <div key={stage.stage} className="flex flex-col items-center flex-1">
              <motion.div
                initial={{ opacity: 0, scale: 0 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="flex flex-col items-center cursor-pointer group mb-6"
                onClick={() => toggleStage(index)}
              >
                <motion.div
                  className={`w-12 h-12 xl:w-14 xl:h-14 rounded-full flex items-center justify-center text-xl xl:text-2xl mb-3 transition-all duration-300 ${
                    activeStage === index ? "scale-125 shadow-lg" : "hover:scale-110"
                  }`}
                  style={{
                    backgroundColor: activeStage === index ? getColor(stage) : "transparent",
                    border: `3px solid ${getColor(stage)}`,
                  }}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {stage.icon}
                </motion.div>
                <span
                  className={`text-sm xl:text-base font-medium text-center transition-colors duration-300 max-w-20 ${
                    activeStage === index ? "text-[#075056] dark:text-[#9ECFD6]" : "text-foreground"
                  }`}
                >
                  {stage.stage}
                </span>
              </motion.div>

              {/* Content appears below each stage */}
              <AnimatePresence>
                {activeStage === index && (
                  <motion.div
                    initial={{ opacity: 0, height: 0, y: -20 }}
                    animate={{ opacity: 1, height: "auto", y: 0 }}
                    exit={{ opacity: 0, height: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                    className="w-full max-w-sm"
                  >
                    <div className="bg-card p-6 shadow-lg border border-border rounded-lg">
                      <div className="flex items-center gap-3 mb-4">
                        <div
                          className="w-10 h-10 rounded-full flex items-center justify-center text-xl"
                          style={{ backgroundColor: getColor(stage) + "20" }}
                        >
                          {stage.icon}
                        </div>
                        <div>
                          <h4 className="text-lg font-light text-[#075056] dark:text-[#9ECFD6]">{stage.stage}</h4>
                          <div className="w-8 h-1 rounded-full" style={{ backgroundColor: getColor(stage) }}></div>
                        </div>
                      </div>

                      <p className="text-foreground text-sm leading-relaxed mb-4">{stage.content}</p>

                      <div>
                        <h5 className="text-sm font-medium text-[#075056] dark:text-[#9ECFD6] mb-3">Key Features:</h5>
                        <div className="space-y-2">
                          {stage.features.map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center gap-2">
                              <div
                                className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                                style={{ backgroundColor: getColor(stage) }}
                              ></div>
                              <span className="text-foreground text-xs">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>

      {/* Mobile/Tablet Timeline - Vertical Stack */}
      <div className="lg:hidden space-y-4">
        {lifeStages.map((stage, index) => (
          <div key={stage.stage}>
            <motion.button
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className={`w-full flex items-center gap-4 p-4 rounded-lg transition-all duration-300 ${
                activeStage === index ? "bg-card shadow-md border-l-4" : "bg-muted hover:bg-card hover:shadow-sm"
              }`}
              style={{
                borderLeftColor: activeStage === index ? getColor(stage) : "transparent",
              }}
              onClick={() => toggleStage(index)}
            >
              <div
                className={`w-12 h-12 rounded-full flex items-center justify-center text-2xl transition-all duration-300 ${
                  activeStage === index ? "scale-110" : ""
                }`}
                style={{
                  backgroundColor: activeStage === index ? getColor(stage) + "20" : "transparent",
                  border: `2px solid ${getColor(stage)}`,
                }}
              >
                {stage.icon}
              </div>
              <div className="flex-1 text-left">
                <span
                  className={`text-base font-medium transition-colors duration-300 ${
                    activeStage === index ? "text-[#075056] dark:text-[#9ECFD6]" : "text-foreground"
                  }`}
                >
                  {stage.stage}
                </span>
              </div>
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: activeStage === index ? getColor(stage) : "#D3DBDD" }}
              ></div>
            </motion.button>

            {/* Content appears below each mobile card */}
            <AnimatePresence>
              {activeStage === index && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="mt-4"
                >
                  <div className="bg-card p-6 shadow-lg border border-border rounded-lg ml-4">
                    <p className="text-foreground text-sm md:text-base leading-relaxed mb-4">{stage.content}</p>

                    <div>
                      <h5 className="text-sm md:text-base font-medium text-[#075056] dark:text-[#9ECFD6] mb-3">
                        Key Features:
                      </h5>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {stage.features.map((feature, featureIndex) => (
                          <div key={featureIndex} className="flex items-center gap-2">
                            <div
                              className="w-2 h-2 rounded-full flex-shrink-0"
                              style={{ backgroundColor: getColor(stage) }}
                            ></div>
                            <span className="text-foreground text-xs md:text-sm">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </div>
  )
}
