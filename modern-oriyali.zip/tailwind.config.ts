import type { Config } from "tailwindcss"
import defaultConfig from "shadcn/ui/tailwind.config"

const config: Config = {
  ...defaultConfig,
  content: [
    ...defaultConfig.content,
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    ...defaultConfig.theme,
    extend: {
      ...defaultConfig.theme.extend,
      colors: {
        ...defaultConfig.theme.extend.colors,
        brand: {
          orange: "#FF5B04", // Orange (Pantone)
          green: "#075056", // Midnight Green
          gunmetal: "#233038", // Gunmetal
          cream: "#FDF6E3", // Ivory Cream
          yellow: "#F4D47C", // Sand Yellow
          silver: "#D3DBDD", // Light Silver
        },
      },
      fontFamily: {
        sans: ["Sora", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [...defaultConfig.plugins, require("tailwindcss-animate")],
}

export default config
